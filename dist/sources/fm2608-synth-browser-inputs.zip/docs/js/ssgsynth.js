import {noteToHz} from './soundchip_pitch.js';
/** @file Browser / Worker / Node.js. AY-compatible SSG register helper; no audio output or DOM. */
const integer = (name, value, max) => {
  if (!Number.isInteger(value) || value < 0 || value > max) throw new RangeError(`Invalid SSG ${name}`);
  return value;
};
/** Three tone/noise channels sharing one noise generator and one envelope. */
export class SSGSynth {
  #levels = new Uint8Array(3);
  /** @param {{transport: {write: (register: number, value: number) => void}, clock: number}} options
   * clock is the effective SSG clock, not necessarily the package's master clock.
   */
  constructor({transport, clock}) {
    if (!transport || typeof transport.write !== 'function') throw new TypeError('SSG requires write(register, value)');
    if (!Number.isFinite(clock) || clock <= 0) throw new RangeError('Invalid SSG clock');
    this.transport = transport;
    this.clock = clock;
    this.resetState();
  }
  /** Reset tracked registers after the parent chip was reset. Does not write hardware. */
  resetState() { this.registers = new Uint8Array(16); this.#levels.fill(0); }
  /** Internal performance snapshot, including levels retained while keyed off. */
  _getState() { return {registers: Array.from(this.registers), levels: Array.from(this.#levels)}; }
  /** Adopt a performance shadow without bus writes; older register-only snapshots remain supported. */
  _adoptState({registers, levels}) {
    this.registers.set(registers);
    this.#levels.set(levels ?? Array.from(registers).slice(8, 11));
  }
   /** Track parent Synth raw writes so mixer changes preserve other channels and I/O bits. @param {number} register  @param {number} value */
  observeWrite(register, value) { if (register >= 0 && register < 16) this.registers[register] = value; if (register >= 8 && register <= 10) this.#levels[register - 8] = value; }
  /** @param {number} register
   * @param {number} value */
  write(register, value) {
    integer('register', register, 15); integer('value', value, 255);
    this.transport.write(register, value);
    this.observeWrite(register, value);
  }
  /** Silence/reset SSG audio registers only; FM and I/O registers are preserved. */
  reset() {
    for (let r = 0; r <= 13; r++) this.write(r, r === 7 ? (this.registers[7] & 0xc0) | 0x3f : 0);
  }
  /** @param {number} channel 0..2.
   * @param {{period?: number, frequency?: number, note?: string|number, volume?: number, envelope?: boolean}} options
   * volume is hardware level 0..15 (0=silent). period overrides frequency.
   */
  tone(channel, {period, frequency, note, volume = 12, envelope = false} = {}) {
    integer('channel', channel, 2); integer('volume', volume, 15);
    if (typeof envelope !== 'boolean') throw new TypeError('SSG envelope must be boolean');
    if (period === undefined) {
      if (frequency === undefined && note !== undefined) frequency = noteToHz(note);
      if (!Number.isFinite(frequency) || frequency <= 0) throw new RangeError('Invalid SSG frequency');
      period = Math.max(1, Math.min(4095, Math.round(this.clock / (16 * frequency))));
    }
    integer('period', period, 4095);
    this.write(channel * 2, period & 255);
    this.write(channel * 2 + 1, period >> 8);
    this.setMixer(channel, {tone: true, noise: false});
    this.setVolume(channel, volume, envelope);
    return period;
  }
  /** Configure Hz without changing mixer or volume. @param {number} channel @param {number} hz */
  setFrequency(channel, hz) {
    integer('channel', channel, 2);
    if (!Number.isFinite(hz) || hz <= 0) throw new RangeError('Frequency must be positive finite Hz');
    const period = Math.max(1, Math.min(4095, Math.round(this.clock / (16 * hz))));
    this.setTonePeriod(channel, period); return period;
  }
  /** @param {number} channel @param {string|number} note */
  setNote(channel, note) { return this.setFrequency(channel, noteToHz(note)); }
  /** Enable tone and restore configured volume/envelope selection; retain noise gates. @param {number} channel */
  keyOn(channel) {
    integer('channel', channel, 2);
    this.write(7, this.registers[7] & ~(1 << channel)); this.write(8 + channel, this.#levels[channel]);
  }
  /** Silence this channel while remembering volume/envelope and pitch. Shared noise and other channels keep their settings.
   * @param {number} channel */
  keyOff(channel) {
    integer('channel', channel, 2); const level = this.#levels[channel];
    this.write(8 + channel, 0); this.#levels[channel] = level;
  }
  /** @param {number} channel @param {string|number} note */
  noteOn(channel, note) { this.setNote(channel, note); this.keyOn(channel); }
  /** @param {number} channel */
  noteOff(channel) { this.keyOff(channel); }
  /** Enable shared noise on one channel. Changing period affects all noise-enabled channels. @param {number} channel */
  noise(channel, {period = 16, volume = 10, envelope = false} = {}) {
    integer('channel', channel, 2); integer('period', period, 31); integer('volume', volume, 15);
    if (typeof envelope !== 'boolean') throw new TypeError('SSG envelope must be boolean');
    this.write(6, period);
    this.setMixer(channel, {tone: false, noise: true});
    this.setVolume(channel, volume, envelope);
  }
  /** Change only tone pitch, preserving mixer/volume. Raw 12-bit hardware period. @param {number} channel @param {number} period */
  setTonePeriod(channel, period) {
    integer('channel', channel, 2); integer('period', period, 4095);
    this.write(channel * 2, period & 255);
    this.write(channel * 2 + 1, period >> 8);
  }
  /** Mixer gates may combine tone and noise on the same channel. @param {number} channel */
  setMixer(channel, {tone, noise}) {
    integer('channel', channel, 2);
    if ((tone !== undefined && typeof tone !== 'boolean') || (noise !== undefined && typeof noise !== 'boolean'))
      throw new TypeError('SSG mixer expects booleans');
    let mixer = this.registers[7];
    if (tone !== undefined) mixer = tone ? mixer & ~(1 << channel) : mixer | (1 << channel);
    if (noise !== undefined) mixer = noise ? mixer & ~(8 << channel) : mixer | (8 << channel);
    if (tone !== undefined || noise !== undefined) this.write(7, mixer);
  }
  /** Envelope selection replaces fixed volume with the shared hardware envelope. @param {number} channel @param {number} volume */
  setVolume(channel, volume, envelope) {
    integer('channel', channel, 2); integer('volume', volume, 15);
    if (envelope !== undefined && typeof envelope !== 'boolean') throw new TypeError('SSG envelope must be boolean');
    const useEnvelope = envelope ?? Boolean(this.#levels[channel] & 16);
    this.write(8 + channel, useEnvelope ? 16 : volume);
  }
  /** @param {number} channel */
  off(channel) { this.keyOff(channel); }
  /** Set the shared envelope period/shape; writing shape retriggers the envelope. */
  setEnvelope({period, shape}) {
    if (period !== undefined) integer('envelope period', period, 65535);
    if (shape !== undefined) integer('shape', shape, 15);
    if (period !== undefined) {
      this.write(11, period & 255);
      this.write(12, period >> 8);
    }
    if (shape !== undefined) this.write(13, shape);
  }
}
