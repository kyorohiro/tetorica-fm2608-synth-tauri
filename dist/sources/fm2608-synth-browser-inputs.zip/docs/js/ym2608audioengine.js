/**
 * @file ym2608audioengine.js
 * 実行環境: Browser / Node.js
 * 依存: 音源チップ／WASM バックエンド（ファクトリーまたはエンジンを注入）。
 * 同期 PCM 生成・ミックス用。DOM・AudioContext・スピーカー出力は不要。
 */
import { Ym2608, YM2608_CLOCK, normalizeYm2608OutputGains } from "./ym2608.js?v=ym2608-output-gains-1";

const DEFAULT_OUTPUT_SAMPLE_RATE = 44100;

/**
 * Ym2608AudioEngine adapter for synchronous stereo rendering and VGM register dispatch.
 * Output timing uses sampleRate() frames per second. No browser audio device is opened.
 * Dispose the engine when done to release its underlying chips.
 */
export class Ym2608AudioEngine {
  #states = new WeakMap();
  /** @param {Ym2608} ym2608
   * @param {number} chipSampleRate
   * @param {number} outputSampleRate
   * @param {number} [masterVolume] */
  constructor(
    ym2608,
    chipSampleRate,
    outputSampleRate,
    masterVolume = 1
  ) {
    this.ym2608 = ym2608;
    this._chipSampleRate = chipSampleRate;
    this._sampleRate = outputSampleRate;
    this._masterVolume = clampMasterVolume(masterVolume);
    this._sourceMuteMask = 0;
    this._rhythmRomRevision = 0;
    this._resampleRemainder = 0;
    this._lastLeft = 0;
    this._lastRight = 0;
    this._sampleCounts = new Uint32Array(128);
  }

  /**
   * Create the chip instances required by this engine.
   * @param {{ym2608ModuleFactory: import('./soundchip.js?v=pokey-prepare-1').WasmModuleFactory, ym2608ModuleOptions?: import('./soundchip.js?v=pokey-prepare-1').WasmModuleOptions, ym2608Clock?: number, outputSampleRate?: number, masterVolume?: number, outputGains?:import('./ym2608.js?v=ym2608-output-gains-1').Ym2608OutputGainPatch}} [options={}] Chip factories, clocks in Hz and loader settings.
   * @param {number} [options.outputSampleRate=44100] Output stereo frames per second.
   * @param {number} [options.masterVolume=1] Linear output gain, not dB.
   * @returns {Promise<Ym2608AudioEngine>} Initialized engine owned by the caller.
   */
  static async create(options = {}) {
    const {
      ym2608ModuleFactory,
      ym2608ModuleOptions,
      ym2608Clock = YM2608_CLOCK,
      outputSampleRate = DEFAULT_OUTPUT_SAMPLE_RATE,
      masterVolume = 1,
      outputGains,
    } = options;

    if (!ym2608ModuleFactory) {
      throw new Error("ym2608ModuleFactory is required");
    }
    const gains = outputGains === undefined ? null : normalizeYm2608OutputGains(outputGains);

    const ym2608 = await Ym2608.create({
      moduleFactory: ym2608ModuleFactory,
      moduleOptions: ym2608ModuleOptions,
    });
    try {
      if (gains) ym2608.setOutputGains(gains);
    } catch (error) { ym2608.dispose(); throw error; }
    const chipSampleRate = ym2608.sampleRate(ym2608Clock);

    return new Ym2608AudioEngine(
      ym2608,
      chipSampleRate,
      outputSampleRate,
      masterVolume
    );
  }

  supportsState() { return !this.writeOki6258 && Boolean(this.ym2608.supportsState?.()); }
  stateSettingsKey() { return JSON.stringify([this._chipSampleRate, this._sampleRate, this._masterVolume, this._sourceMuteMask, this._rhythmRomRevision, this.getOutputGains()]); }
  /** @returns {Readonly<{byteLength:number}>} Opaque snapshot owned by this instance. */
  saveState() {
    if (!this.supportsState()) throw new Error('OPN state saving unavailable');
    const chip = this.ym2608.saveState();
    const state = Object.freeze({byteLength: chip.byteLength + 64});
    this.#states.set(state, {chip, key: this.stateSettingsKey(), timing: [this._resampleRemainder, this._lastLeft, this._lastRight]});
    return state;
  }
  /** @param {Readonly<{byteLength:number}>} state Snapshot returned by this instance. */
  validateState(state) {
    const saved = this.#states.get(state);
    if (!this.supportsState() || !saved || saved.key !== this.stateSettingsKey()) throw new Error('Incompatible OPN state');
    this.ym2608.validateState(saved.chip);
  }
  /** @param {Readonly<{byteLength:number}>} state Snapshot returned by this instance. */
  loadState(state) {
    this.validateState(state);
    const saved = this.#states.get(state);
    this.ym2608.loadState(saved.chip);
    [this._resampleRemainder, this._lastLeft, this._lastRight] = saved.timing;
  }

  /**
   * Release the underlying chips and their resources. Do not render after disposal.
   * @returns {void}
   */
  dispose() {
    this.ym2608.dispose();
  }

  /**
   * Reset chip/playback state for a new pass. This is not pause/resume; replay setup writes afterward.
   * @returns {void}
   */
  reset() {
    this.ym2608.reset();
    this.clearAdpcmBMemory();
    this._resampleRemainder = 0;
    this._lastLeft = 0;
    this._lastRight = 0;
  }

  /**
   * Return the rate used by process() and processFrames().
   * @returns {number} Output stereo frames per second (Hz).
   */
  sampleRate() {
    return this._sampleRate;
  }

  /**
   * Set the linear master gain; validation/clamping follows this engine.
   * @param {number} volume Gain multiplier, not dB.
   */
  setMasterVolume(volume) {
    this._masterVolume = clampMasterVolume(volume);
    return this._masterVolume;
  }

  /**
   * Read the current linear master gain.
   * @returns {number} Gain multiplier, not a dB value.
   */
  getMasterVolume() {
    return this._masterVolume;
  }

  /** Host gains are applied to the native FM-side and SSG outputs before mixing.
   * FM includes Rhythm and ADPCM-B. Changing gains invalidates cached engine states.
   * @param {import('./ym2608.js?v=ym2608-output-gains-1').Ym2608OutputGainPatch} gains Partial linear gains, each 0..1024.
   * @returns {import('./ym2608.js?v=ym2608-output-gains-1').Ym2608OutputGains} Accepted gains.
   */
  setOutputGains(gains) { return this.ym2608.setOutputGains(gains); }

  /** @returns {import('./ym2608.js?v=ym2608-output-gains-1').Ym2608OutputGains} Detached output gains. */
  getOutputGains() { return this.ym2608.getOutputGains?.() ?? {fm:1,ssg:1}; }

  /**
   * Dispatch a VGM register/command write to the corresponding sound chip.
   * @param {number} port Chip register bank/port (not a MIDI channel).
   * @param {number} register Register address within the selected chip bank.
   * @param {number} value Register/command data value.
   */
  writeYm2608(port, register, value) {
    this.ym2608.write(port * 2, register);
    this.ym2608.write((port * 2) + 1, value);
  }

  /** @param {Uint8Array} bytes
   * @param {number} [offset] */
  loadAdpcmARom(bytes, offset = 0) {
    this.ym2608.loadAdpcmARom(bytes, offset);
    this._rhythmRomRevision++;
  }

  /** @param {Uint8Array} bytes
   * @param {number} memorySize
   * @param {number} offset */
  loadAdpcmBMemory(bytes, offset = 0, memorySize) {
    this.ym2608.loadAdpcmBMemory(bytes, offset, memorySize);
  }

  clearAdpcmBMemory() {
    this.ym2608.clearAdpcmBMemory();
  }

  /** @param {boolean} muted */
  setSsgMuted(muted) { this.setSourceMuted(1, muted); }
  /** @param {boolean} muted */
  setRhythmMuted(muted) { this.setSourceMuted(2, muted); }
  /** @param {boolean} muted */
  setAdpcmBMuted(muted) { this.setSourceMuted(4, muted); }

   /** @param {boolean} muted  @param {number} bit */
  setSourceMuted(bit, muted) {
    const mask = muted ? this._sourceMuteMask | bit : this._sourceMuteMask & ~bit;
    this.ym2608.setSourceMuteMask(mask);
    this._sourceMuteMask = mask;
  }

  /**
   * Dispatch a VGM register/command write to the corresponding sound chip.
   * @param {number} _value Ignored; this engine has no Sega PSG output.
   */
  writePsg(_value) {}

  /**
   * Advance synthesis and fill caller-owned stereo buffers.
   * @param {Float32Array} left Left output buffer with capacity for frames samples.
   * @param {Float32Array} right Right output buffer with capacity for frames samples.
   * @param {number} frames Nonnegative integer output frame count; not VGM wait samples.
   */
  process(left, right, frames) {
    if (!(left instanceof Float32Array) || !(right instanceof Float32Array)) {
      throw new Error("process expects Float32Array buffers");
    }
    if (left.length < frames || right.length < frames) {
      throw new Error("process buffers are smaller than the requested frame count");
    }

    // A user IRQ callback can write registers synchronously. Keep its previous
    // per-output-frame observation points; realtime worklets install no hook.
    const blockFrames = typeof this.ym2608.hooks?.onIrq === 'function' ? 1 : 128;
    for (let outputOffset = 0; outputOffset < frames; outputOffset += blockFrames) {
      const count = Math.min(blockFrames,frames-outputOffset);
      let sourceFrames = 0;
      // Timelines split this call at register-write boundaries. Bounded source
      // batches also keep long offline renders within the native frame limit.
      for (let index = 0; index < count; index++) {
        this._resampleRemainder += this._chipSampleRate;
        const samplesToMix = Math.floor(this._resampleRemainder / this._sampleRate);
        this._resampleRemainder -= samplesToMix * this._sampleRate;
        this._sampleCounts[index] = samplesToMix;
        sourceFrames += samplesToMix;
      }
      const ym = sourceFrames ? (this.ym2608.generateStereoView ?? this.ym2608.generateStereo).call(this.ym2608,sourceFrames) : null;
      let offset = 0;
      for (let index = 0; index < count; index++) {
        const samplesToMix = this._sampleCounts[index];
        // During upsampling, hold the previous sample without advancing the chip.
        if (samplesToMix > 0) {
          let mixedLeft = 0;
          let mixedRight = 0;
          for (let sampleIndex = 0; sampleIndex < samplesToMix; sampleIndex++, offset++) {
            mixedLeft += ym.left[offset]; mixedRight += ym.right[offset];
          }
          this._lastLeft = mixedLeft / samplesToMix;
          this._lastRight = mixedRight / samplesToMix;
        }
        left[outputOffset+index] = this._lastLeft * this._masterVolume;
        right[outputOffset+index] = this._lastRight * this._masterVolume;
      }
    }
  }

  /**
   * Allocate stereo output and advance synthesis.
   * @param {number} frames Nonnegative integer frame count at sampleRate().
   * @returns {{left:Float32Array,right:Float32Array}} Rendered stereo output.
   */
  processFrames(frames) {
    const left = new Float32Array(frames);
    const right = new Float32Array(frames);
    this.process(left, right, frames);
    return { left, right };
  }
}

/** @param {Parameters<typeof Ym2608AudioEngine.create>[0]} [options] */
export async function createYm2608AudioEngine(options) {
  return Ym2608AudioEngine.create(options);
}

const MAX_MASTER_VOLUME = 3.8;

function clampMasterVolume(value) {
  const numeric = Number(value);

  if (!Number.isFinite(numeric)) {
    throw new Error(
      `master volume must be a finite number, got ${value}`
    );
  }

  return Math.min(
    MAX_MASTER_VOLUME,
    Math.max(0, numeric)
  );
}
